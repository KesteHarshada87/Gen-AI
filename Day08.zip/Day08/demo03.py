from langchain_community.document_loaders import PyPDFLoader
from langchain.embeddings import init_embeddings

embed_model = init_embeddings(
        model="huggingface:sentence-transformers/all-MiniLM-L6-v2"
)

def load_pdf_resume(pdf_path):
    loader = PyPDFLoader(pdf_path)
    docs = loader.load()
    resume_content= ""
    for page in docs:
        resume_content += page.page_content
    metadata = {
        "source": pdf_path,
        "page_count": len(docs)
    }    
    return resume_content, metadata

resume_path = r"C:\Users\Harshada\Downloads\fake-resumes\resume-001.pdf"

resume_text, resume_info = load_pdf_resume(resume_path)
print(resume_info)
print(resume_text)

resume_embeddings = embed_model.embed_documents([resume_text])
for embedding in resume_embeddings:
    print(f"Len = {len(embedding)} --> {embedding[:4]}")
    