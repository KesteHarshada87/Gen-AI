from langchain.embeddings import init_embeddings

embed_model = init_embeddings(
    model="huggingface:sentence-transformers/all-MiniLM-L6-v2"
)

sentences = [
    "I like Artificial Intelligence",
    "Generative AI is magnificent",
    "World is amazing"
]

embeddings = embed_model.embed_documents(sentences)

for embedding in embeddings:
    print(f"Len = {len(embedding)} -> {embedding[:4]}")
