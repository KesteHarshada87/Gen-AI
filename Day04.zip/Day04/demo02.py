import requests
import json

user_prompt = input("Ask anything: ")

url = "http://127.0.0.1:1234/v1/chat/completions"

headers = {
    "Content-Type": "application/json"
}

data = {
    "model": "microsoft/phi-4-mini-reasoning",
    "messages": [
        {"role": "user", "content": user_prompt}
    ],
}

response = requests.post(url, headers=headers, json=data)
print("Status:", response.status_code)

resp = response.json()

# ✅ SAFE extraction for LM Studio
try:
    answer = resp["choices"][0]["message"]["content"]

    # Some models return content as a list
    if isinstance(answer, list):
        answer = answer[0]["text"]

    print("\nAnswer:")
    print(answer)

except KeyError:
    print("\nUnexpected response format:")
    print(json.dumps(resp, indent=2))
