import math_utils as mu

print(mu.area_circle(5))
print(mu.area_rectangle(4, 6))
print(mu.area_triangle(10, 3))
