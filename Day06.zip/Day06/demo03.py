from langchain.chat_models import init_chat_model
from langchain.agents import create_agent
from langchain.tools import tool
from dotenv import load_dotenv
import os
import json
import requests

load_dotenv()

# ---------------- TOOLS ----------------

@tool
def calculator(expression: str) -> str:
    """
    Solves arithmetic expressions.
    """
    try:
        return str(eval(expression))
    except:
        return "Error: Cannot solve expression"


@tool
def get_weather(city: str) -> str:
    """
    Gets current weather of a city using OpenWeather API.
    Returns weather JSON as string.
    """
    api_key = os.getenv("OPENWEATHER_API_KEY")
    if not api_key:
        return "Error: OPENWEATHER_API_KEY not set"

    url = (
        f"https://api.openweathermap.org/data/2.5/weather"
        f"?q={city}&appid={api_key}&units=metric"
    )

    response = requests.get(url)
    if response.status_code != 200:
        return "Error: City not found"

    return json.dumps(response.json())


# ---------------- MODEL ----------------

llm = init_chat_model(
    model="llama-3.3-70b-versatile",
    model_provider="openai",              # Groq is OpenAI-compatible
    base_url="https://api.groq.com/openai/v1",
    api_key=os.getenv("GROQ_API_KEY")
)

# ---------------- AGENT (IMPORTANT FIX) ----------------

agent = create_agent(
    model=llm,
    tools=[calculator, get_weather],
    system_prompt=(
        "You are a helpful assistant. "
        "Use tools ONLY when needed. "
        "Otherwise answer directly."
    )
)

# ---------------- CHAT LOOP ----------------

while True:
    user_input = input("You: ")
    if user_input.lower() == "exit":
        break

    result = agent.invoke({
        "messages": [{"role": "user", "content": user_input}]
    })

    ai_msg = result["messages"][-1]
    print("AI:", ai_msg.content)
