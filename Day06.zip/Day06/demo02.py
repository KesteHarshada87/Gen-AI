from langchain.chat_models import init_chat_model
from langchain.agents import create_agent
from langchain.tools import tool
import os

@tool
def calculator(expression):
    """
    This calculator function solves any arithmetic expression containing all constant values.
    It supports basic arithmetic operators +,-,*,/, and parenthisis.

    :param expression: str input arithmetic expression
    :return expression result as str
    """
    try:
        result = eval(expression)
        return str(result)
    except:
        return "Error: Cannot solve expression"
    
#create model
llm = init_chat_model(
    model = "llama-3.3-70b-versatile",
    model_provider = "openai",
    base_url="https://api.groq.com/openai/v1",
    api_key =  os.getenv("GROQ_API_KEY")
)

#create agent
agent = create_agent(
    model = llm,
    tools=[
        calculator
    ],
    system_prompt="You are a helpful assistant.Answer in short."

)

while True:
    #take input
    user_input = input("You: ")
    if user_input == "exit":
        break

    #invoke agent
    result = agent.invoke({
        "messages":[
            {"role": "user","content": user_input}
        ]
    })

    llm_output = result["messages"][-1]
    print("AI: ",llm_output.content)
    print("\n\n", result["messages"])